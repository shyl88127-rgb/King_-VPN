# VPN Config Switcher (Android)

## چطور اجراش کنم؟
1. کل پوشه `vpn-switcher` رو با Android Studio باز کن (File > Open)
2. بذار Gradle خودش sync بشه (نیاز به اینترنت داره تا وابستگی‌ها رو دانلود کنه)
3. Run بزن روی یه دستگاه/شبیه‌ساز

الان پروژه با یک **MockXrayConnector** کار می‌کنه — یعنی دکمه پاور، انیمیشن‌ها، و منطق
سوییچ خودکار رو واقعی نشون می‌ده، ولی هیچ VPN واقعی وصل نمی‌کنه (فقط شبیه‌سازیه).
برای تست، توی `MainActivity.kt` لینک‌های خودت رو توی `sampleLinks` بذار (چون لیست الان خالیه).

برای اتصال واقعی VPN، باید طبق بخش پایین `XrayConnector` واقعی رو جایگزین `MockXrayConnector` کنی.

## چی ساختیم تا الان
- `ConfigModel.kt` — مدل داده هر کانفیگ + فرمول امتیازدهی
- `ConfigParser.kt` — پارس لینک‌های vmess:// و vless:// و trojan://
- `LatencyTester.kt` — تست موازی تأخیر (TCP connect) و رتبه‌بندی اولیه
- `VpnSwitchManager.kt` — قلب پروژه: اتصال به بهترین کانفیگ + مانیتورینگ دوره‌ای + سوییچ خودکار در صورت قطعی
- `MainViewModel.kt` — وضعیت UI (روشن/خاموش/در حال اتصال/خطا) رو مدیریت می‌کنه
- `MainScreen.kt` — صفحه اصلی با دکمه بزرگ دایره‌ای پاور وسط صفحه (Jetpack Compose)

### درباره UI
دکمه پاور رنگش بسته به وضعیت عوض میشه:
- خاکستری = خاموش
- زرد + پالس = در حال اتصال یا سوییچ
- سبز = وصل
- قرمز = خطا (هیچ کانفیگ فعالی نیست)

با تپ روی دکمه: اگه خاموشه → کانفیگ‌ها رو تست و به بهترین وصل میشه. اگه وصله → قطع میشه.


## چیزی که هنوز جا افتاده (مرحله بعد)
`VpnSwitchManager` به یک `XrayConnector` نیاز داره — این اینترفیسیه که وصلش می‌کنی به
هسته واقعی Xray. برای این کار:

1. کتابخانه [AndroidLibXrayLite](https://github.com/2dust/AndroidLibXrayLite) رو اضافه کن
   (همون هسته‌ای که v2rayNG استفاده می‌کنه، متن‌باز و به‌روزه).
2. یک کلاس بساز مثل `XrayVpnConnector : XrayConnector` که:
   - از `fullConfigJson` کانفیگ (یا برای vless/trojan، یک `XrayConfigBuilder` که باید بسازیم)
     یک کانفیگ کامل JSON برای Xray می‌سازه
   - `VpnService` اندروید رو با `Builder.establish()` بالا میاره (این یعنی باید یک
     `android.net.VpnService` هم داشته باشی که `VpnSwitchManager` رو صدا بزنه)
   - `isTunnelHealthy()` رو با چک وضعیت پروسه Xray و فایل‌دیسکریپتور تانل پیاده کنه

3. `AndroidManifest.xml` نیاز به این پرمیژن‌ها داره:
   ```xml
   <uses-permission android:name="android.permission.INTERNET"/>
   <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
   <service android:name=".YourVpnService"
       android:permission="android.permission.BIND_VPN_SERVICE">
       <intent-filter>
           <action android:name="android.net.VpnService"/>
       </intent-filter>
   </service>
   ```

## نکته درباره vless و trojan
توی `ConfigParser.kt` برای این دو پروتکل `fullConfigJson` رو خالی گذاشتم چون ساختن
JSON کامل Xray برای اون‌ها (streamSettings, tls, reality, ws/grpc و...) بسته به
جزئیات هر کانفیگ فرق می‌کنه. مرحله بعدی منطقی اینه که یک `XrayConfigBuilder` بسازیم
که از روی query params لینک (که توی URI هست) این JSON رو کامل بسازه.

## استفاده نمونه
```kotlin
val manager = VpnSwitchManager(connector = XrayVpnConnector(context))
manager.onStatusChanged = { status, config ->
    Log.d("VPN", "status=$status config=${config?.remark}")
}

lifecycleScope.launch {
    manager.loadAndRank(listOf(
        "vmess://...",
        "vless://...",
        "trojan://..."
    ))
    manager.start()
}
```

## گام‌های پیشنهادی بعدی
1. اضافه کردن `XrayConfigBuilder` برای تکمیل JSON کانفیگ‌های vless/trojan
2. نوشتن `YourVpnService : VpnService` که تانل رو با `Builder` اندروید بالا بیاره
3. UI ساده برای وارد کردن/چسوندن کانفیگ‌ها + نمایش وضعیت زنده
4. ذخیره‌سازی محلی کانفیگ‌ها (DataStore یا Room) تا بین اجراها بمونن

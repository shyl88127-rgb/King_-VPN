package com.example.vpnswitcher

import kotlinx.coroutines.*
import java.net.HttpURLConnection
import java.net.URL

/**
 * رابطی که باید توسط لایه اتصال واقعی به Xray/AndroidLibXrayLite پیاده‌سازی بشه.
 * این لایه جداست تا منطق سوییچ از جزئیات هسته VPN مستقل بمونه.
 */
interface XrayConnector {
    /** اتصال با یک کانفیگ مشخص رو شروع می‌کنه. باید await کنه تا تانل بالا بیاد یا خطا بده. */
    suspend fun connect(config: VpnConfig)

    /** قطع اتصال فعلی */
    suspend fun disconnect()

    /** آیا تانل الان واقعاً داره ترافیک رد می‌کنه (نه فقط سرویس روشنه) */
    suspend fun isTunnelHealthy(): Boolean
}

/**
 * مدیریت کامل چرخه: رتبه‌بندی -> اتصال به بهترین -> مانیتور دوره‌ای -> سوییچ خودکار در صورت قطعی
 */
class VpnSwitchManager(
    private val connector: XrayConnector,
    private val healthCheckIntervalMs: Long = 15_000L,
    private val healthCheckUrl: String = "https://www.gstatic.com/generate_204"
) {
    private var configs: MutableList<VpnConfig> = mutableListOf()
    private var currentConfig: VpnConfig? = null
    private var monitorJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    var onStatusChanged: ((status: String, config: VpnConfig?) -> Unit)? = null

    /**
     * اگه غیر null باشه، یعنی کاربر دستی یه کانفیگ خاص رو انتخاب کرده -> فقط همون
     * وصل میشه (نه بهترین کانفیگ). اگه null باشه یعنی حالت خودکار فعاله.
     */
    var preferredConfigId: String? = null

    /** مرحله اول: کانفیگ‌ها رو می‌گیره، تست و رتبه‌بندی می‌کنه */
    suspend fun loadAndRank(links: List<String>) {
        val parsed = ConfigParser.parseLinks(links)
        configs = LatencyTester.testAndRank(parsed).toMutableList()
        onStatusChanged?.invoke("ranked_${configs.count { it.isAlive }}_alive", null)
    }

    /**
     * شروع کار: اگه کاربر دستی کانفیگ انتخاب کرده باشه (preferredConfigId) همون رو
     * امتحان می‌کنه، وگرنه بهترین کانفیگ زنده رو انتخاب می‌کنه (حالت خودکار)
     */
    suspend fun start() {
        val manual = preferredConfigId?.let { id -> configs.firstOrNull { it.id == id } }
        val best = manual ?: configs.firstOrNull { it.isAlive }
            ?: throw IllegalStateException("هیچ کانفیگ زنده‌ای پیدا نشد")
        connectTo(best)
        startMonitoring()
    }

    fun stop() {
        monitorJob?.cancel()
        scope.launch { connector.disconnect() }
    }

    private suspend fun connectTo(config: VpnConfig) {
        onStatusChanged?.invoke("connecting", config)
        try {
            connector.connect(config)
            currentConfig = config
            onStatusChanged?.invoke("connected", config)
        } catch (e: Exception) {
            config.isAlive = false
            config.failCount++
            onStatusChanged?.invoke("connect_failed", config)
            switchToNextBest()
        }
    }

    /** مانیتورینگ دوره‌ای سلامت اتصال؛ در صورت قطعی خودکار سوییچ می‌کنه */
    private fun startMonitoring() {
        monitorJob?.cancel()
        monitorJob = scope.launch {
            while (isActive) {
                delay(healthCheckIntervalMs)
                val healthy = checkRealConnectivity()
                if (!healthy) {
                    currentConfig?.let {
                        it.isAlive = false
                        it.failCount++
                    }
                    onStatusChanged?.invoke("disconnected", currentConfig)
                    switchToNextBest()
                } else {
                    currentConfig?.successCount = (currentConfig?.successCount ?: 0) + 1
                }
            }
        }
    }

    /** چک واقعی: از طریق تانل یه درخواست HTTP سبک می‌زنه */
    private suspend fun checkRealConnectivity(): Boolean = withContext(Dispatchers.IO) {
        try {
            val tunnelUp = connector.isTunnelHealthy()
            if (!tunnelUp) return@withContext false

            val conn = URL(healthCheckUrl).openConnection() as HttpURLConnection
            conn.connectTimeout = 5000
            conn.readTimeout = 5000
            conn.requestMethod = "GET"
            val code = conn.responseCode
            conn.disconnect()
            code in 200..299 || code == 204
        } catch (e: Exception) {
            false
        }
    }

    /**
     * میره سراغ بهترین کانفیگ بعدی که هنوز امتحان نشده/قطع نشده.
     * اگه همه تموم شدن، دوباره کل لیست رو تست و رتبه‌بندی می‌کنه (شاید یکی برگشته باشه)
     */
    private suspend fun switchToNextBest() {
        val currentId = currentConfig?.id
        val candidates = configs
            .filter { it.id != currentId && it.isAlive }
            .sortedBy { it.score() }

        val next = candidates.firstOrNull()
        if (next != null) {
            onStatusChanged?.invoke("switching", next)
            connectTo(next)
        } else {
            // هیچ کاندید زنده‌ای نمونده -> دوباره کل لیست رو تست کن
            onStatusChanged?.invoke("retesting_all", null)
            configs = LatencyTester.testAndRank(configs).toMutableList()
            val revived = configs.firstOrNull { it.isAlive }
            if (revived != null) {
                connectTo(revived)
            } else {
                onStatusChanged?.invoke("all_dead", null)
            }
        }
    }
}

package com.example.vpnswitcher

/**
 * مدل نگهداری اطلاعات یک کانفیگ V2Ray/Xray
 * (پشتیبانی از vmess, vless, trojan)
 */
data class VpnConfig(
    val id: String,           // شناسه یکتا (مثلاً هش لینک)
    val rawLink: String,      // لینک اصلی: vmess://... یا vless://... یا trojan://...
    val protocol: String,     // "vmess" | "vless" | "trojan"
    val address: String,      // آدرس سرور
    val port: Int,            // پورت سرور
    val remark: String,       // نام نمایشی کانفیگ
    val fullConfigJson: String, // خروجی نهایی JSON که به هسته Xray داده میشه
    val localProxyPort: Int = 10808 // پورت پروکسی محلی (SOCKS) که خود کانفیگ روش گوش میده
) {
    // آمار عملکرد که در طول زمان آپدیت میشه
    var lastLatencyMs: Long = Long.MAX_VALUE
    var isAlive: Boolean = false
    var successCount: Int = 0
    var failCount: Int = 0
    var lastCheckedAt: Long = 0L

    /**
     * امتیاز کلی کانفیگ برای رتبه‌بندی.
     * هرچی امتیاز کمتر بهتره (شبیه گلف): پینگ کمتر + شکست کمتر = بهتر
     * کانفیگ‌های مرده (isAlive=false) امتیاز خیلی بد می‌گیرن تا ته لیست برن
     */
    fun score(): Double {
        if (!isAlive) return Double.MAX_VALUE
        val failPenalty = failCount * 500.0 // هر شکست ۵۰۰ میلی‌ثانیه جریمه
        val successBonus = successCount * -10.0 // هر موفقیت کمی امتیاز بهتر می‌ده
        return lastLatencyMs + failPenalty + successBonus
    }
}

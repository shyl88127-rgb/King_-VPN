package com.example.vpnswitcher

import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.net.InetSocketAddress
import java.net.Socket

/**
 * تست تأخیر (latency) کانفیگ‌ها با یک TCP connect ساده به آدرس:پورت سرور.
 * این یه پیش‌تست سریعه (قبل از وصل کردن واقعی VPN) که کمک می‌کنه
 * سریع‌ترین/پایدارترین کانفیگ‌ها رو برای اولویت اول انتخاب کنیم.
 *
 * نکته: این فقط چک می‌کنه سرور در دسترسه، نه اینکه پروکسی واقعاً کار می‌کنه.
 * برای تست دقیق‌تر (واقعاً از طریق پروکسی یک URL رو باز کن) از
 * RealProxyHealthChecker استفاده کن که بعد از وصل شدن VPN اجرا میشه.
 */
object LatencyTester {

    private const val TIMEOUT_MS = 3000
    private const val PARALLEL_LIMIT = 8

    /**
     * همه کانفیگ‌ها رو موازی تست می‌کنه و نتیجه رو داخل خود آبجکت‌ها آپدیت می‌کنه.
     * خروجی: لیست مرتب‌شده بر اساس امتیاز (بهترین اول)
     */
    suspend fun testAndRank(configs: List<VpnConfig>): List<VpnConfig> = coroutineScope {
        val semaphore = Semaphore(PARALLEL_LIMIT)
        val jobs = configs.map { config ->
            async(Dispatchers.IO) {
                semaphore.withPermit {
                    testOne(config)
                }
            }
        }
        jobs.awaitAll()
        configs.sortedBy { it.score() }
    }

    private fun testOne(config: VpnConfig) {
        val start = System.currentTimeMillis()
        try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(config.address, config.port), TIMEOUT_MS)
                val elapsed = System.currentTimeMillis() - start
                config.lastLatencyMs = elapsed
                config.isAlive = true
                config.successCount++
            }
        } catch (e: Exception) {
            config.lastLatencyMs = Long.MAX_VALUE
            config.isAlive = false
            config.failCount++
        } finally {
            config.lastCheckedAt = System.currentTimeMillis()
        }
    }
}

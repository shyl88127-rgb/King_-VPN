package com.example.vpnswitcher

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.filled.Check
import androidx.compose.ui.window.Dialog
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun MainScreen(viewModel: MainViewModel) {
    val uiState by viewModel.uiState
    val statusText by viewModel.statusText
    val activeConfigName by viewModel.activeConfigName

    val ringColor = when (uiState) {
        VpnUiState.CONNECTED -> Color(0xFF2ECC71)      // سبز = وصل
        VpnUiState.CONNECTING, VpnUiState.SWITCHING -> Color(0xFFF1C40F) // زرد = در حال تلاش
        VpnUiState.ERROR -> Color(0xFFE74C3C)          // قرمز = خطا
        VpnUiState.DISCONNECTED -> Color(0xFF7F8C8D)   // خاکستری = خاموش
    }

    // انیمیشن پالس برای حالت‌های در حال اتصال/سوییچ
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )
    val isBusy = uiState == VpnUiState.CONNECTING || uiState == VpnUiState.SWITCHING

    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // نشون‌دهنده حالت فعلی: خودکار یا دستی (بالای دکمه اصلی)
            val selectedConfigId by viewModel.selectedConfigId
            val modeLabel = if (selectedConfigId == null) {
                "حالت: خودکار"
            } else {
                val label = viewModel.configOptions.firstOrNull { it.id == selectedConfigId }?.label
                "حالت: انتخاب دستی ($label)"
            }
            Text(
                text = modeLabel,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(16.dp))

            // دکمه بزرگ به شکل کره سه‌بعدی وسط صفحه
            BoxWithConstraints(
                modifier = Modifier
                    .size(180.dp)
                    .shadow(
                        elevation = 28.dp,
                        shape = CircleShape,
                        ambientColor = ringColor.copy(alpha = 0.6f),
                        spotColor = ringColor.copy(alpha = 0.6f)
                    )
                    .clip(CircleShape)
                    .clickable { viewModel.onPowerButtonClicked() },
                contentAlignment = Alignment.Center
            ) {
                val widthPx = with(androidx.compose.ui.platform.LocalDensity.current) { maxWidth.toPx() }
                val heightPx = with(androidx.compose.ui.platform.LocalDensity.current) { maxHeight.toPx() }
                val baseColor = ringColor.copy(alpha = if (isBusy) pulseAlpha else 1f)

                // گرادیان کروی: نور از بالا-چپ می‌تابه، لبه‌ها تیره‌تر میشن -> حس عمق و برجستگی
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    lighten(baseColor, 0.35f),
                                    baseColor,
                                    darken(baseColor, 0.45f)
                                ),
                                center = Offset(widthPx * 0.32f, heightPx * 0.28f),
                                radius = widthPx * 0.95f
                            )
                        )
                )

                // هایلایت شیشه‌ای گلوسی بالای کره
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(start = 34.dp, top = 22.dp)
                        .size(width = 62.dp, height = 38.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    Color.White.copy(alpha = 0.55f),
                                    Color.White.copy(alpha = 0.0f)
                                )
                            )
                        )
                )

                Icon(
                    imageVector = Icons.Filled.PowerSettingsNew,
                    contentDescription = "روشن / خاموش",
                    tint = Color.White,
                    modifier = Modifier.size(72.dp)
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            Text(
                text = statusText,
                fontSize = 18.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onBackground
            )

            if (activeConfigName != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "کانفیگ فعال: $activeConfigName",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(40.dp))

            // آیکون کره زمین: با زدنش یه پنجره جدا برای انتخاب دستی کانفیگ باز میشه
            var showConfigDialog by remember { mutableStateOf(false) }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(MaterialTheme.shapes.medium)
                    .clickable { showConfigDialog = true }
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Public,
                    contentDescription = "انتخاب کانفیگ",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "انتخاب کانفیگ",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (showConfigDialog) {
                Dialog(onDismissRequest = { showConfigDialog = false }) {
                    Card(shape = MaterialTheme.shapes.large) {
                        Column(modifier = Modifier.padding(vertical = 12.dp)) {
                            Text(
                                text = "انتخاب کانفیگ",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                            )

                            LazyColumn(modifier = Modifier.heightIn(max = 360.dp)) {
                                item {
                                    ConfigDialogRow(
                                        label = "خودکار",
                                        selected = selectedConfigId == null,
                                        onClick = {
                                            viewModel.selectAuto()
                                            showConfigDialog = false
                                        }
                                    )
                                }
                                items(viewModel.configOptions) { option ->
                                    ConfigDialogRow(
                                        label = option.label,
                                        selected = selectedConfigId == option.id,
                                        onClick = {
                                            viewModel.selectManualConfig(option.id)
                                            showConfigDialog = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // نمایش آدرس پروکسی محلی (SOCKS) با قابلیت کپی، برای استفاده در سایر اپ‌ها
            val localProxyPort by viewModel.localProxyPort
            val clipboardManager = LocalClipboardManager.current
            val proxyAddress = "127.0.0.1:$localProxyPort"

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(MaterialTheme.shapes.medium)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Text(
                    text = "پروکسی محلی: $proxyAddress",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.width(8.dp))
                Icon(
                    imageVector = Icons.Filled.ContentCopy,
                    contentDescription = "کپی آدرس پروکسی",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .size(18.dp)
                        .clickable {
                            clipboardManager.setText(AnnotatedString(proxyAddress))
                        }
                )
            }
        }
    }
}

/** یک ردیف قابل‌کلیک داخل پنجره انتخاب کانفیگ، با تیک کنار گزینه انتخاب‌شده */
@Composable
private fun ConfigDialogRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 20.dp, vertical = 14.dp)
    ) {
        Text(
            text = label,
            fontSize = 15.sp,
            modifier = Modifier.weight(1f),
            color = MaterialTheme.colorScheme.onSurface
        )
        if (selected) {
            Icon(
                imageVector = Icons.Filled.Check,
                contentDescription = "انتخاب‌شده",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

/** رنگ رو به سمت سفید روشن‌تر می‌کنه (برای افکت نور روی کره) */
private fun lighten(color: Color, amount: Float): Color {
    return Color(
        red = color.red + (1f - color.red) * amount,
        green = color.green + (1f - color.green) * amount,
        blue = color.blue + (1f - color.blue) * amount,
        alpha = color.alpha
    )
}

/** رنگ رو به سمت سیاه تیره‌تر می‌کنه (برای افکت سایه لبه کره) */
private fun darken(color: Color, amount: Float): Color {
    return Color(
        red = color.red * (1f - amount),
        green = color.green * (1f - amount),
        blue = color.blue * (1f - amount),
        alpha = color.alpha
    )
}

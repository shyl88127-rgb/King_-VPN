package com.example.vpnswitcher

import android.util.Base64
import org.json.JSONObject
import java.net.URI
import java.net.URLDecoder
import java.security.MessageDigest

/**
 * پارس کردن لینک‌های اشتراک‌گذاری V2Ray/Xray به مدل VpnConfig
 * پشتیبانی: vmess://, vless://, trojan://
 */
object ConfigParser {

    fun parseLinks(links: List<String>): List<VpnConfig> {
        return links.mapNotNull { link ->
            try {
                parseSingle(link.trim())
            } catch (e: Exception) {
                // کانفیگ خراب یا فرمت ناشناخته -> رد میشه، بقیه کار می‌کنن
                null
            }
        }
    }

    private fun parseSingle(link: String): VpnConfig? {
        val trimmed = link.trim()
        return when {
            trimmed.startsWith("vmess://") -> parseVmess(trimmed)
            trimmed.startsWith("vless://") -> parseVless(trimmed)
            trimmed.startsWith("trojan://") -> parseTrojan(trimmed)
            trimmed.startsWith("{") -> parseFullJson(trimmed)
            else -> null
        }
    }

    /**
     * پارس یک کانفیگ کامل Xray به فرمت JSON (همون چیزی که خروجی نهایی هسته می‌خواد).
     * این فرمت خودش شامل inbounds/outbounds/dns/routing هست، پس نیازی به
     * ساخت اضافه با XrayConfigBuilder نداره -> مستقیم fullConfigJson = خود متن.
     */
    private fun parseFullJson(json: String): VpnConfig {
        val root = JSONObject(json)
        val outbounds = root.getJSONArray("outbounds")

        var address = ""
        var port = 0
        var protocol = "unknown"

        for (i in 0 until outbounds.length()) {
            val ob = outbounds.getJSONObject(i)
            if (ob.optString("tag") == "proxy") {
                protocol = ob.optString("protocol", "unknown")
                val settings = ob.optJSONObject("settings")
                when (protocol) {
                    "vless", "vmess" -> {
                        val vnext = settings?.optJSONArray("vnext")?.optJSONObject(0)
                        address = vnext?.optString("address") ?: ""
                        port = vnext?.optInt("port") ?: 0
                    }
                    "trojan", "shadowsocks" -> {
                        val servers = settings?.optJSONArray("servers")?.optJSONObject(0)
                        address = servers?.optString("address") ?: ""
                        port = servers?.optInt("port") ?: 0
                    }
                }
                break
            }
        }

        // پورت پروکسی محلی (SOCKS) که این کانفیگ روش گوش میده -> از inbounds خونده میشه
        val inbounds = root.optJSONArray("inbounds")
        val localProxyPort = inbounds?.optJSONObject(0)?.optInt("port", 10808) ?: 10808

        // remark واقعی (اگه توی JSON بود) عمداً توی UI استفاده نمیشه -> جای دیگه
        // (مثل MainViewModel) با یک برچسب خنثی مثل "کانفیگ ۱" جایگزین میشه.
        val remark = root.optString("remarks", "config")

        return VpnConfig(
            id = idFor(json),
            rawLink = json,
            protocol = protocol,
            address = address,
            port = port,
            remark = remark,
            fullConfigJson = json,
            localProxyPort = localProxyPort
        )
    }

    private fun idFor(link: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        val hash = md.digest(link.toByteArray())
        return hash.joinToString("") { "%02x".format(it) }.take(16)
    }

    private fun parseVmess(link: String): VpnConfig {
        val b64 = link.removePrefix("vmess://")
        val decoded = String(Base64.decode(b64, Base64.DEFAULT))
        val json = JSONObject(decoded)

        val address = json.getString("add")
        val port = json.getInt("port")
        val remark = json.optString("ps", "vmess-config")

        return VpnConfig(
            id = idFor(link),
            rawLink = link,
            protocol = "vmess",
            address = address,
            port = port,
            remark = remark,
            fullConfigJson = decoded
        )
    }

    private fun parseVless(link: String): VpnConfig {
        val uri = URI(link)
        val address = uri.host
        val port = uri.port
        val remark = uri.fragment?.let { URLDecoder.decode(it, "UTF-8") } ?: "vless-config"

        // برای سادگی، JSON نهایی رو در مرحله ساخت کانفیگ کامل (XrayConfigBuilder) می‌سازیم
        return VpnConfig(
            id = idFor(link),
            rawLink = link,
            protocol = "vless",
            address = address,
            port = port,
            remark = remark,
            fullConfigJson = "" // در XrayConfigBuilder تکمیل میشه
        )
    }

    private fun parseTrojan(link: String): VpnConfig {
        val uri = URI(link)
        val address = uri.host
        val port = uri.port
        val remark = uri.fragment?.let { URLDecoder.decode(it, "UTF-8") } ?: "trojan-config"

        return VpnConfig(
            id = idFor(link),
            rawLink = link,
            protocol = "trojan",
            address = address,
            port = port,
            remark = remark,
            fullConfigJson = "" // در XrayConfigBuilder تکمیل میشه
        )
    }
}

package com.example.vpnswitcher

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

enum class VpnUiState { DISCONNECTED, CONNECTING, CONNECTED, SWITCHING, ERROR }

/** یک گزینه کانفیگ برای نمایش در لیست انتخاب دستی (فقط برچسب خنثی، بدون اسم/لینک واقعی) */
data class ConfigOption(val id: String, val label: String)

class MainViewModel(
    private val manager: VpnSwitchManager,
    private val links: List<String> // کانفیگ‌های ذخیره‌شده کاربر
) : ViewModel() {

    val uiState = mutableStateOf(VpnUiState.DISCONNECTED)
    val statusText = mutableStateOf("خاموش")
    val activeConfigName = mutableStateOf<String?>(null)
    // پورت پروکسی محلی (SOCKS) کانفیگ فعال؛ قبل از اتصال، پورت پیش‌فرض اولین کانفیگ نشون داده میشه
    val localProxyPort = mutableStateOf(
        ConfigParser.parseLinks(links).firstOrNull()?.localProxyPort ?: 10808
    )

    // برچسب خنثی برای هر کانفیگ (کانفیگ ۱، کانفیگ ۲...) به‌جای نمایش اسم/لینک واقعی
    // ترتیب بر اساس همون ترتیبی هست که کاربر لینک‌ها رو وارد کرده، نه ترتیب رتبه‌بندی
    private val labelMap: Map<String, String> = ConfigParser.parseLinks(links)
        .mapIndexed { index, config -> config.id to "کانفیگ ${index + 1}" }
        .toMap()

    /** لیست گزینه‌های قابل‌انتخاب دستی، برای نمایش در ردیف زیر دکمه اصلی */
    val configOptions: List<ConfigOption> = labelMap.entries
        .sortedBy { it.value } // به ترتیب کانفیگ ۱، ۲، ۳...
        .map { ConfigOption(it.key, it.value) }

    /** null یعنی حالت خودکار؛ غیر null یعنی کاربر دستی این کانفیگ رو انتخاب کرده */
    val selectedConfigId = mutableStateOf<String?>(null)

    private fun labelFor(config: VpnConfig?): String? =
        config?.let { labelMap[it.id] ?: "کانفیگ" }

    init {
        manager.onStatusChanged = { status, config ->
            when (status) {
                "connecting" -> {
                    uiState.value = VpnUiState.CONNECTING
                    statusText.value = "در حال اتصال..."
                }
                "connected" -> {
                    uiState.value = VpnUiState.CONNECTED
                    statusText.value = "متصل"
                    activeConfigName.value = labelFor(config)
                    localProxyPort.value = config?.localProxyPort ?: 10808
                }
                "switching" -> {
                    uiState.value = VpnUiState.SWITCHING
                    statusText.value = "در حال سوییچ به کانفیگ بهتر..."
                }
                "disconnected" -> {
                    statusText.value = "قطع شد، در حال پیدا کردن کانفیگ جدید..."
                }
                "connect_failed" -> {
                    statusText.value = "اتصال ناموفق، امتحان بعدی..."
                }
                "all_dead" -> {
                    uiState.value = VpnUiState.ERROR
                    statusText.value = "هیچ کانفیگ فعالی پیدا نشد"
                }
                "retesting_all" -> {
                    statusText.value = "در حال تست دوباره همه کانفیگ‌ها..."
                }
            }
        }
    }

    fun onPowerButtonClicked() {
        when (uiState.value) {
            VpnUiState.DISCONNECTED, VpnUiState.ERROR -> connect()
            VpnUiState.CONNECTED, VpnUiState.SWITCHING, VpnUiState.CONNECTING -> disconnect()
        }
    }

    /** برگردوندن به حالت خودکار: خودش بهترین کانفیگ رو انتخاب و در صورت قطعی سوییچ می‌کنه */
    fun selectAuto() {
        selectedConfigId.value = null
        manager.preferredConfigId = null
        reconnectIfActive()
    }

    /** انتخاب دستی یک کانفیگ مشخص از لیست */
    fun selectManualConfig(id: String) {
        selectedConfigId.value = id
        manager.preferredConfigId = id
        reconnectIfActive()
    }

    /** اگه در حال اتصال یا متصل بودیم، با انتخاب جدید دوباره وصل میشه */
    private fun reconnectIfActive() {
        if (uiState.value == VpnUiState.CONNECTED ||
            uiState.value == VpnUiState.CONNECTING ||
            uiState.value == VpnUiState.SWITCHING
        ) {
            manager.stop()
            connect()
        }
    }

    private fun connect() {
        uiState.value = VpnUiState.CONNECTING
        statusText.value = "در حال تست کانفیگ‌ها..."
        viewModelScope.launch {
            try {
                manager.loadAndRank(links)
                manager.start()
            } catch (e: Exception) {
                uiState.value = VpnUiState.ERROR
                statusText.value = "خطا: ${e.message}"
            }
        }
    }

    private fun disconnect() {
        manager.stop()
        uiState.value = VpnUiState.DISCONNECTED
        statusText.value = "خاموش"
        activeConfigName.value = null
    }
}

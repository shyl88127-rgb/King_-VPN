package com.example.vpnswitcher

import kotlinx.coroutines.delay
import kotlin.random.Random

/**
 * پیاده‌سازی آزمایشی XrayConnector فقط برای تست UI و منطق سوییچ،
 * بدون نیاز به هسته واقعی Xray. هیچ VPN واقعی وصل نمی‌کنه.
 *
 * وقتی AndroidLibXrayLite رو اضافه کردی، این کلاس رو با یک
 * پیاده‌سازی واقعی (که VpnService اندروید رو بالا میاره) جایگزین کن.
 */
class MockXrayConnector : XrayConnector {

    private var connected = false
    private var shouldFailRandomly = true

    override suspend fun connect(config: VpnConfig) {
        delay(1200) // شبیه‌سازی زمان برقراری اتصال

        // برای دیدن رفتار "قطع و سوییچ خودکار"، گاهی وصل شدن رو fail می‌کنیم
        if (shouldFailRandomly && Random.nextInt(100) < 15) {
            connected = false
            throw RuntimeException("اتصال آزمایشی شکست خورد (شبیه‌سازی)")
        }
        connected = true
    }

    override suspend fun disconnect() {
        connected = false
    }

    override suspend fun isTunnelHealthy(): Boolean {
        // برای دیدن رفتار "قطعی ناگهانی و سوییچ خودکار"، گاهی هلث‌چک رو fail می‌کنیم
        if (connected && Random.nextInt(100) < 10) {
            connected = false
        }
        return connected
    }
}
